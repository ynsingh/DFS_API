package client;

import java.nio.file.*;

//import static client.WatchDir.startWatchDir;
import client.WatchDir;
import dfs3Util.file;
import dfs3test.communication.Receiver;

import static java.nio.file.StandardWatchEventKinds.*;
import static java.nio.file.LinkOption.*;
import java.nio.file.attribute.*;
import java.io.*;
import java.security.GeneralSecurityException;
import java.util.*;

public class DFSinit {

    public static void main (String args[]) throws IOException, GeneralSecurityException {

        DFSInfo wrt = new DFSInfo();
        System.out.println("Welcome to B4 DFS");
        System.out.println("This is Brihaspati 4 Distributed File System : A peer-to-peer cloud storage system");
        System.out.println("You will get cloud storage 50% that of local storage offered (e.g.500MB cloud storage for 1GB local disk space offered)");
        System.out.println("Please create a new empty folder for DFS.");
        System.out.println("Please specify the full directory path of DFS Folder:");

        Scanner sc = new Scanner(System.in);
        wrt.dfsDir = sc.nextLine();

        System.out.println("Please specify local storage space offered in MB:");
        wrt.localspace = sc.nextLong();

        System.out.println("Your DFS Directory is: " + wrt.dfsDir);
        if(wrt.localspace<wrt.localfree)
        System.out.println("You will get " + wrt.localspace / 2 + "MB of cloud storage");
        else
            System.out.println("Insufficient Memory in the local disk drive");

        Thread rx = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Receiver.start();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        rx.start();

        WatchDir.startWatchDir(wrt.dfsDir);

    }
}

class DFSInfo implements Serializable  {
        String dfsDir;
        long localspace;
        long cloudAuth = localspace/2;
        long cloudOccupied;
        long localfree;
        long localOccupied;
        long cloudBal;

    public DFSInfo() {
        File diskdtl = new File(System.getProperty("user.dir"));
        localfree = diskdtl.getFreeSpace();
        System.out.println("Free local space in user directory is: " + localfree/(1024*1024*1024) + "GB");

    }
}