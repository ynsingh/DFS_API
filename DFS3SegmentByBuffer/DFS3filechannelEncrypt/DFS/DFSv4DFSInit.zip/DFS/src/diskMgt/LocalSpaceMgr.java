package diskMgt;
import java.io.*;
public class LocalSpaceMgr {
    /*static void LocalSpaceMgr {


        File file = new File(System.getProperty("user.dir"));

        double diskCpbGB = file.getTotalSpace()/(1024.0 * 1024 * 1024);
        System.out.println( "Partition size is: " + diskCpbGB +"GB");

        double localSpaceGB = file.getFreeSpace()/(1024.0 * 1024 * 1024);
        System.out.println( "Free space on the disk is: " + localSpaceGB+"GB");

        double cloudSpaceGB = localSpaceGB/2;
        System.out.println( "P2P cloud storage being offered is: " + cloudSpaceGB+"GB");


   }*/

}

