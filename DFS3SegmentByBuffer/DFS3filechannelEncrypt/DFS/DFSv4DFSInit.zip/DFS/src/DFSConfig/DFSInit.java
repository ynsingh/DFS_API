package DFSConfig;

import client.WatchDir;
import dfs3test.communication.Receiver;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class DFSInit {

    public static void main(String[] args) {

        System.out.println("Welcome to B4 DFS!");
        DFSConfig dfsconfig = DFSConfig.getInstance();
        Thread rx = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Receiver.start();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        rx.start();

        //WatchDir.startWatchDir(.dfsDir);

    }

}

class DFSConfig implements Serializable {

    private static volatile DFSConfig config;
    String rootinode;
    String PubU = null;
    String PubN = null;
    double initlocalFree;
    double localfree;
    double localOffered;
    double localOccupied=0;
    double cloudAuth;
    double cloudOccupied=0;
    double cloudAvlb = cloudAuth - cloudOccupied;
    double localCacheSize=0.1*cloudAuth;
    double cacheOccupied=0;

    String dfsDir;
    String dfsSrvr;
    String dfsCache;
    static String configFile;

    private DFSConfig(){
        //Prevent form the reflection api.
        if (config != null){
            throw new RuntimeException("Use getInstance() method to get the single instance of this class.");
        }
    }

    public static DFSConfig getInstance() {
        if (config == null) { //if there is no instance available... create new one
            synchronized (DFSConfig.class) {
                if (config == null) config = new DFSConfig();
                configFile=System.getProperty("user.dir")+System.getProperty("file.separator")+ "b4dfs"+System.getProperty("file.separator")+ "configFile.txt";
                File configfile = new File(configFile);
                if(configfile.exists()==false) config.firstInit();
                else config.regInit();
            }
        }
        return config;
    }

    //Make singleton safe from serialize and deserialize operation.
    protected DFSConfig readResolve() {
        return getInstance();
    }
    void firstInit()
    {
        System.out.println("This is Brihaspati 4 Distributed File System : A peer-to-peer cloud storage system");
        System.out.println("You will get cloud storage 50% that of local storage offered (e.g.500MB cloud storage for 1GB local disk space offered)");
        //Functions to get emailID, pubU and and pvtU
        System.out.println("Please specify your registered email ID for B4:");
        Scanner sc = new Scanner(System.in);
        String mailid=sc.nextLine();
        config.rootinode = "dfs://"+mailid+"/";

        File file = new File(System.getProperty("user.dir"));
        config.initlocalFree= file.getFreeSpace() / (1024.0 * 1024 * 1024);
        int i=0;
        while(i<3) {
            System.out.println("Please specify local disk to be offered in GB:");
            config.localOffered=sc.nextDouble();
            if(config.initlocalFree<config.localOffered)
            {
                System.out.println("Local Space available is "+ config.initlocalFree +"GB");
                System.out.println("Please specify space less than available space");
                i=i+1;
                continue;
            }
            else
            {
                config.cloudAuth=config.localOffered/2;
                System.out.println("You have obtained "+config.cloudAuth+"GB of cloud space");
                System.out.println("Your root inode is "+config.rootinode);
                break;
            }
        }
        if(i==3) System.out.println("You have exceeded the attempts");

        config.dfsDir = System.getProperty("user.dir")+System.getProperty("file.separator")+ "b4dfs";
        Path pathDir = Paths.get(config.dfsDir);

        config.dfsSrvr = config.dfsDir + System.getProperty("file.separator")+ "dfsSrvr";
        Path pathSrvr = Paths.get(config.dfsSrvr);

        config.dfsCache = config.dfsDir + System.getProperty("file.separator")+ "dfsCache";
        Path pathCache = Paths.get(config.dfsCache);

        Path pathFile = Paths.get(configFile);


        try {
            Files.createDirectory(pathDir);
            System.out.println("DFS directory created successfully");
            Files.createDirectory(pathSrvr);
            System.out.println("DFS server directory created successfully");
            Files.createDirectory(pathCache);
            System.out.println("DFS cache directory created successfully");
            Files.createFile(pathFile);
            System.out.println("DFS configuration file created successfully");
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        try {
            FileOutputStream fos = new FileOutputStream(configFile);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(config);;
            oos.close();
            System.out.println("DFS Config file initialized successfully");
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
    void regInit()
    {
        System.out.println("DFS is already initialized");
        System.out.println("Configuration file is in: "+configFile);

        try {
            FileInputStream fis= new FileInputStream(configFile);
            ObjectInputStream ois = new ObjectInputStream(fis);

            config = (DFSConfig)ois.readObject();
            System.out.println("Your root inode is: "+config.rootinode);
            System.out.println("Your authorized cloud space is: "+config.cloudAuth);
            ois.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
